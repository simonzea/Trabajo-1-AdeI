CREATE DATABASE Contaminacion

USE Contaminacion

CREATE TABLE Certificacion
(
Instrument_Status int Primary Key NOT NULL,
Description Varchar(30) NOT NULL,
);

CREATE TABLE Contaminante
(
Item_Code int Primary Key NOT NULL,
Item_Name Varchar(10) NOT NULL,
Unit_of_Measurment Varchar(20) NOT NULL,
Good float NOT NULL,
Normal float NOT NULL,
Bad float NOT NULL,
Very_Bad float NOT NULL,
);

CREATE TABLE Estacion
(
Station_Code int Primary Key NOT NULL,
Station_Name Varchar (30) NOT NULL,
Address_Station Varchar (100) NOT NULL,
Latitude float NOT NULL,
Longitude float NOT NULL
);

CREATE TABLE Medicion
(
Measurment_Date datetime NOT NULL,
Station_Code int NOT NULL,
Item_Code int NOT NULL,
Average_Value float NOT NULL,
Instrument_Status int NOT NULL,
)

