/****** Script for SelectTopNRows command from SSMS  ******/

USE Contaminacion

  --Valor promedio y m�ximo general para todas las estaciones por contaminante 
 SELECT C.Item_Name, ROUND(AVG(M.Average_Value),4) AS Promedio, MAX(M.Average_Value) AS Maximo 
 FROM Medicion AS M JOIN Contaminante AS C ON M.Item_Code = C.Item_Code
 GROUP BY C.Item_Name ORDER BY C.Item_Name;

 --Valor promedio, m�nimo y m�ximo por contaminante para cada estaci�n
 SELECT E.Station_Name, C.Item_Name, ROUND(AVG(M.Average_Value),4) AS Promedio, MAX(M.Average_Value) AS Maximo 
 FROM Medicion AS M JOIN Estacion AS E ON M.Station_Code = E.Station_Code JOIN Contaminante AS C ON M.Item_Code = C.Item_Code 
 GROUP BY E.Station_Name, C.Item_Name ORDER BY C.Item_Name;
 
 --Cuenta de registros clasificados en los rangos malo (Bad) y muy malo (Very Bad) para cada contaminante
 SELECT COUNT(Average_Value) AS SO2_Bad FROM Medicion WHERE Item_Code = 1 AND Average_Value > 0.15;
 SELECT COUNT(Average_Value) AS NO2_Bad FROM Medicion WHERE Item_Code = 3 AND Average_Value > 0.2;
 SELECT COUNT(Average_Value) AS CO_Bad FROM Medicion WHERE Item_Code = 5 AND Average_Value > 15;
 SELECT COUNT(Average_Value) AS O3_Bad FROM Medicion WHERE Item_Code = 6 AND Average_Value > 0.15;

 --Identificaci�n de la estaci�n y la fecha en que se presentaron las concentraciones de contaminaci�n a partir de las cuales son consideradas como malas (Bad)
 SELECT Measurment_Date, Station_Code, Average_Value FROM Medicion WHERE Item_Code = 1 AND Average_Value > 0.15;
 SELECT Measurment_Date, Station_Code, Average_Value FROM Medicion WHERE Item_Code = 3 AND Average_Value > 0.2;
 SELECT Measurment_Date, Station_Code, Average_Value FROM Medicion WHERE Item_Code = 5 AND Average_Value > 15;
 SELECT Measurment_Date, Station_Code, Average_Value FROM Medicion WHERE Item_Code = 6 AND Average_Value > 0.15;

 --Valor promedio para cada contaminante por mes 
 SELECT Item_Code, MONTH(Measurment_Date) AS Mes, ROUND(AVG(Average_Value),4) AS Promedio FROM Medicion 
 GROUP BY MONTH(Measurment_Date), Item_Code ORDER BY Item_Code, AVG(Average_Value) DESC; 

  --Valor m�ximo para cada contaminante por mes 
 SELECT Item_Code, MONTH(Measurment_Date) AS Mes, MAX(Average_Value) AS Maximo FROM Medicion 
 GROUP BY MONTH(Measurment_Date), Item_Code ORDER BY Item_Code, MAX(Average_Value) DESC; 